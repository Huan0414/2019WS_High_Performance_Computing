var searchData=
[
  ['addbound',['AddBound',['../geom_8cpp.html#ad09e166e591d01fc74041124f4b9b0b3',1,'AddBound(int const ib, int const nx, int const ny, double w[], double const s[]):&#160;geom.cpp'],['../geom_8h.html#a6954c6e0aaa76a1197f69809671f3fe9',1,'AddBound(int ib, int nx, int ny, double w[], double const s[]):&#160;geom.cpp']]],
  ['addelem',['AddElem',['../getmatrix_8cpp.html#a0e5a78e809ca20f811d12c9cb0f84510',1,'AddElem(int const ial[3], double const ske[3][3], double const fe[3], int const id[], int const ik[], double sk[], double f[]):&#160;getmatrix.cpp'],['../getmatrix_8h.html#a0e5a78e809ca20f811d12c9cb0f84510',1,'AddElem(int const ial[3], double const ske[3][3], double const fe[3], int const id[], int const ik[], double sk[], double f[]):&#160;getmatrix.cpp']]],
  ['addelem_5f3',['AddElem_3',['../class_c_r_s___matrix.html#afd887068b4a25a3eddb7a7c6dc202727',1,'CRS_Matrix']]],
  ['applydirichletbc',['ApplyDirichletBC',['../class_c_r_s___matrix.html#a6316235a7ffc373830d3534a4e78cb6f',1,'CRS_Matrix']]],
  ['ascii_5fwrite_5fmesh',['ascii_write_mesh',['../ascii__write__mesh_8m.html#a88625a1dc65fb63f87282bdedc5d37a5',1,'ascii_write_mesh.m']]]
];
