var searchData=
[
  ['norm',['norm',['../mylib_8cpp.html#a735efccbb7bd970b9374f4b8ccd1f5ca',1,'norm(vector&lt; double &gt; const &amp;x):&#160;mylib.cpp'],['../mylib_8h.html#a9170237c001917a7296a3c4c4c7b4504',1,'norm(std::vector&lt; double &gt; const &amp;x):&#160;mylib.h']]]
];
