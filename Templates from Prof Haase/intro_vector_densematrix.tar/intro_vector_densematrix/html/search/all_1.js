var searchData=
[
  ['operator_2a',['operator*',['../mylib_8h.html#a975b13316f7b41920e027b7820a345e6',1,'operator*(std::vector&lt; std::vector&lt; double &gt;&gt; const &amp;A, std::vector&lt; double &gt; const &amp;u):&#160;mylib.h'],['../mylib_8h.html#aaa64c33d9af7e3c9488884a1b0d64810',1,'operator*(std::vector&lt; double &gt; const &amp;A, std::vector&lt; double &gt; const &amp;u):&#160;mylib.h']]]
];
