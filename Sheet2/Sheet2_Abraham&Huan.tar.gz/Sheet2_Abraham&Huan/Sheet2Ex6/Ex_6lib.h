#ifndef FILE MYLIB
#define FILE MYLIB

// Innerproduct
void exA(int const NLOOPS, int const N);
// MatrixVector
void exB(int const NLOOPS,int const M, int const N);
// MatrixMatrix
void exC(int const NLOOPS, int const M,int const N,int const L);

#endif
