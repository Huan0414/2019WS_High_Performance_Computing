var searchData=
[
  ['reduction_5fvec',['reduction_vec',['../mylib_8cpp.html#af96e66bafc6ab5dc2902ffc2285d9df5',1,'reduction_vec(int n):&#160;mylib.cpp'],['../mylib_8h.html#a2af5df8f5174faf1ff4bacfd43b66763',1,'reduction_vec(int n):&#160;mylib.cpp']]]
];
