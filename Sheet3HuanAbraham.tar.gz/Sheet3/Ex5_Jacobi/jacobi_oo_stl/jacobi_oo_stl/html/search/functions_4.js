var searchData=
[
  ['getbound',['GetBound',['../geom_8cpp.html#af9672ad43cbb17b5086a483f8d33fcd8',1,'GetBound(int const ib, int const nx, int const ny, double const w[], double s[]):&#160;geom.cpp'],['../geom_8h.html#a0aecb857920b52071fac2e7bf2cc03ed',1,'GetBound(int ib, int nx, int ny, double const w[], double s[]):&#160;geom.cpp']]],
  ['getconnectivity',['GetConnectivity',['../class_mesh.html#a394f0e3661f24af69b1cc266fd105ee5',1,'Mesh::GetConnectivity() const'],['../class_mesh.html#ac8135cc3b903f22dd6c6ecb915a57a15',1,'Mesh::GetConnectivity()']]],
  ['getcoords',['GetCoords',['../class_mesh.html#ab8905df61a71b216fc3c23eb0791d8e6',1,'Mesh::GetCoords() const'],['../class_mesh.html#af57aa8573268c899e80c93914813c247',1,'Mesh::GetCoords()']]],
  ['getdiag',['GetDiag',['../class_c_r_s___matrix.html#ae7651d5e4d0af5713fe9e93a3f9bc8b1',1,'CRS_Matrix']]]
];
