var searchData=
[
  ['tmp',['tmp',['../ascii__write__mesh_8m.html#ab996992ad0d4b5c0690e4ba6247d6806',1,'ascii_write_mesh.m']]],
  ['txt',['txt',['../visualize__results_8m.html#a1d9ecaeadfa29b5b4a3e296f1e80acd2',1,'visualize_results.m']]]
];
