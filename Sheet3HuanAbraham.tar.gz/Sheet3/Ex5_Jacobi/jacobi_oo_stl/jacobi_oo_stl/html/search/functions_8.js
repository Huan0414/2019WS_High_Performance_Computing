var searchData=
[
  ['ndims',['Ndims',['../class_mesh.html#a4f0333a6720c78894ecfa9d478fda759',1,'Mesh']]],
  ['ndofselement',['NdofsElement',['../class_mesh.html#ae31bd82d2c50f34929fd2355b205a8fd',1,'Mesh']]],
  ['nelems',['Nelems',['../class_mesh.html#a8865a5338ed9fc6cfcf8380e5fd066ca',1,'Mesh']]],
  ['nnodes',['Nnodes',['../class_mesh.html#aa8e9755d13c5b70588b4becdae8ebf01',1,'Mesh']]],
  ['nrows',['Nrows',['../class_c_r_s___matrix.html#a0438e95786cf2432341f3ebf1fa92184',1,'CRS_Matrix']]],
  ['nverticeselements',['NverticesElements',['../class_mesh.html#ab49f1a2a5fbe38b1aad81a8d8d84797d',1,'Mesh']]]
];
