var searchData=
[
  ['ndim',['ndim',['../ascii__read__meshvector_8m.html#af916768081f1e75b2163d083fdc446c2',1,'ndim():&#160;ascii_read_meshvector.m'],['../ascii__write__mesh_8m.html#af916768081f1e75b2163d083fdc446c2',1,'ndim():&#160;ascii_write_mesh.m']]],
  ['ndims',['Ndims',['../class_mesh.html#a4f0333a6720c78894ecfa9d478fda759',1,'Mesh']]],
  ['ndofselement',['NdofsElement',['../class_mesh.html#ae31bd82d2c50f34929fd2355b205a8fd',1,'Mesh']]],
  ['nelem',['nelem',['../ascii__read__meshvector_8m.html#a33b3477c7761a8a3b98cb4fa916f4eba',1,'nelem():&#160;ascii_read_meshvector.m'],['../ascii__write__mesh_8m.html#a33b3477c7761a8a3b98cb4fa916f4eba',1,'nelem():&#160;ascii_write_mesh.m']]],
  ['nelems',['Nelems',['../class_mesh.html#a8865a5338ed9fc6cfcf8380e5fd066ca',1,'Mesh']]],
  ['nnode',['nnode',['../ascii__write__mesh_8m.html#aac1f81c46f10d4ac4321e8facf7fc0df',1,'ascii_write_mesh.m']]],
  ['nnodes',['Nnodes',['../class_mesh.html#aa8e9755d13c5b70588b4becdae8ebf01',1,'Mesh']]],
  ['nrows',['Nrows',['../class_c_r_s___matrix.html#a0438e95786cf2432341f3ebf1fa92184',1,'CRS_Matrix']]],
  ['nvert',['nvert',['../ascii__read__meshvector_8m.html#a9af9eb801b919743833adca0ac0ac3ca',1,'ascii_read_meshvector.m']]],
  ['nvert_5fe',['nvert_e',['../ascii__write__mesh_8m.html#abba3071043b2d84e4790dd27c0401720',1,'ascii_write_mesh.m']]],
  ['nverticeselements',['NverticesElements',['../class_mesh.html#ab49f1a2a5fbe38b1aad81a8d8d84797d',1,'Mesh']]]
];
