var searchData=
[
  ['ndim',['ndim',['../ascii__read__meshvector_8m.html#af916768081f1e75b2163d083fdc446c2',1,'ndim():&#160;ascii_read_meshvector.m'],['../ascii__write__mesh_8m.html#af916768081f1e75b2163d083fdc446c2',1,'ndim():&#160;ascii_write_mesh.m']]],
  ['nelem',['nelem',['../ascii__read__meshvector_8m.html#a33b3477c7761a8a3b98cb4fa916f4eba',1,'nelem():&#160;ascii_read_meshvector.m'],['../ascii__write__mesh_8m.html#a33b3477c7761a8a3b98cb4fa916f4eba',1,'nelem():&#160;ascii_write_mesh.m']]],
  ['nnode',['nnode',['../ascii__write__mesh_8m.html#aac1f81c46f10d4ac4321e8facf7fc0df',1,'ascii_write_mesh.m']]],
  ['nvert',['nvert',['../ascii__read__meshvector_8m.html#a9af9eb801b919743833adca0ac0ac3ca',1,'ascii_read_meshvector.m']]],
  ['nvert_5fe',['nvert_e',['../ascii__write__mesh_8m.html#abba3071043b2d84e4790dd27c0401720',1,'ascii_write_mesh.m']]]
];
