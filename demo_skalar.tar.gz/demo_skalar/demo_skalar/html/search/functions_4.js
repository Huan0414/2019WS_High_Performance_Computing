var searchData=
[
  ['scalar',['scalar',['../mylib_8cpp.html#a213cc0a8ab21abe98baab44fb6fed885',1,'scalar(vector&lt; double &gt; const &amp;x, vector&lt; double &gt; const &amp;y):&#160;mylib.cpp'],['../mylib_8h.html#a0f1c75f2f78c31bdd097b2a464e62838',1,'scalar(std::vector&lt; double &gt; const &amp;x, std::vector&lt; double &gt; const &amp;y):&#160;mylib.h']]]
];
