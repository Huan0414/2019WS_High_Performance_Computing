#ifndef CUTHILL_MCKEE_ORDERING
#define CUTHILL_MCKEE_ORDERING

#include <vector>

std::vector<int> cuthill_mckee_reordering(std::vector<int> const &_edges);

#endif
