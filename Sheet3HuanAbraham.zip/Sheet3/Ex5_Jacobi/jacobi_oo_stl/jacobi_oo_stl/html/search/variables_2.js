var searchData=
[
  ['col_5f1',['col_1',['../ascii__read__meshvector_8m.html#a8d158494c904f636bdca6dc863625159',1,'ascii_read_meshvector.m']]],
  ['connectivity',['connectivity',['../ascii__write__mesh_8m.html#afeca4bc55594d6204f1ebeaac274347b',1,'ascii_write_mesh.m']]]
];
