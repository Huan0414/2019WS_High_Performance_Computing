var searchData=
[
  ['vdaxpy',['vdaxpy',['../vdop_8cpp.html#a8373e1f53c0a09b40628abb418be9b1d',1,'vdaxpy(std::vector&lt; double &gt; &amp;x, std::vector&lt; double &gt; const &amp;y, double alpha, std::vector&lt; double &gt; const &amp;z):&#160;vdop.cpp'],['../vdop_8h.html#a8373e1f53c0a09b40628abb418be9b1d',1,'vdaxpy(std::vector&lt; double &gt; &amp;x, std::vector&lt; double &gt; const &amp;y, double alpha, std::vector&lt; double &gt; const &amp;z):&#160;vdop.cpp']]],
  ['vddiv',['vddiv',['../vdop_8cpp.html#aa6989077542658fb26baf1bcbd0eff97',1,'vddiv(vector&lt; double &gt; &amp;x, vector&lt; double &gt; const &amp;y, vector&lt; double &gt; const &amp;z):&#160;vdop.cpp'],['../vdop_8h.html#aaeef473e07102df9d6bcef0a218a83c6',1,'vddiv(std::vector&lt; double &gt; &amp;x, std::vector&lt; double &gt; const &amp;y, std::vector&lt; double &gt; const &amp;z):&#160;vdop.h']]],
  ['visualize',['Visualize',['../class_mesh.html#afedd75816d19e7bdca582f4ffc63e6ce',1,'Mesh']]]
];
