var searchData=
[
  ['jacobisolve',['JacobiSolve',['../jacsolve_8cpp.html#a5a374199a3b656437fd7f9d0319a412a',1,'JacobiSolve(CRS_Matrix const &amp;SK, vector&lt; double &gt; const &amp;f, vector&lt; double &gt; &amp;u):&#160;jacsolve.cpp'],['../jacsolve_8h.html#a4b66d6c4de6f3c7b26bbf39d0f7054f0',1,'JacobiSolve(CRS_Matrix const &amp;SK, std::vector&lt; double &gt; const &amp;f, std::vector&lt; double &gt; &amp;u):&#160;jacsolve.h']]]
];
