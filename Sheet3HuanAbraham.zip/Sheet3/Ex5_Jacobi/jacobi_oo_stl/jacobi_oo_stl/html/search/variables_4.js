var searchData=
[
  ['g',['g',['../square_8m.html#a33cfc70bbdd994c483edd87359de4e65',1,'square.m']]]
];
