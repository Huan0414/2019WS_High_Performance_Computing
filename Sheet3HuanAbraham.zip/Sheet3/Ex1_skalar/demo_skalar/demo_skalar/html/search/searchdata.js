var indexSectionsWithContent =
{
  0: "cmors",
  1: "cm",
  2: "cmors"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions"
};

